# IITBombay-thesis-latex
IITBombay PhD Thesis latex source files
These files generate a template for PhD thesis of Indian Institute of Technology Bombay, India. 
Master file: thesis.tex
Reference: Reference/mybibfile.bib   It generates (Author, year) style citations and follows elsarticle-harv.bst files.
Figures: Images can be directed from this folder.
